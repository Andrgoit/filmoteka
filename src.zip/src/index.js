import ApiService from './js/api-service';
const newApiService = new ApiService();

//  == refs ==
const refs = {
  form: document.querySelector('.search-form'),
  gallery: document.querySelector('#gallery-list'),
};

//   == listeners ==
refs.form.addEventListener('submit', inputHandler);

//  == First Load Page ==
// firstPageLoader();

function firstPageLoader() {
  window.addEventListener('DOMContentLoaded', getTrendingMovie);
}

async function getTrendingMovie() {
  newApiService.resetPage();
  try {
    const response = await newApiService.fetchTrendingUrl();
    console.log(response);
    markupMovies(response);
  } catch (error) {
    console.log(error);
  }
}
//  == // First Load Page ==

function markupMovies(response) {
  console.log(response.results);

  const imageUrl = 'https://image.tmdb.org/t/p/';
  const imageSize = 'w500';
  const movies = response.results;

  const markup = movies
    .map(({ id, genre_ids, original_title, release_date, poster_path }) => {
      return `<li class="gallery-item" id="${id}">
        <div class="gallery-image"><img src="${imageUrl}${imageSize}${poster_path}" alt="${original_title}"></div>
        <h2 class="gallery-item-title">${original_title}</h2>
        <span class="gallery-item-prop">${genre_ids} | ${release_date}</span>
      </li>`;
    })
    .join('');

  refs.gallery.innerHTML = markup;
}

async function inputHandler(e) {
  e.preventDefault();
  refs.gallery.innerHTML = '';
  newApiService.input = e.currentTarget.elements.searchInput.value.trim();
  console.log(newApiService.input);
  newApiService.resetPage();
  if (newApiService.input !== '') {
    try {
      const response = await newApiService.fetchSearch();
      // console.log(response);
      markupMovies(response);
    } catch (error) {
      console.log(error);
    }
  }
  return;
}
